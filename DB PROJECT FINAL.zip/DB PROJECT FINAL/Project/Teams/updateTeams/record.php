<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psl_management_system";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">PSL Teams Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Team ID</th>
<th>Team Name</th>
<th>Team Contact</th>

</tr>
<?php
$sql = "SELECT * FROM team";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['Team_id'];?></td>
<td> <?php  echo $row['TName'];?></td>
<td> <?php  echo $row['TContact'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['Team_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>