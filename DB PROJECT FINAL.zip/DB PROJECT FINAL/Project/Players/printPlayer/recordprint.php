<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psl_management_system";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Players</title>
</head>
<body>
    <section class="showcase">

            <div class="filter"></div>

            <header>
                    <h2 class="logo"><a class="navbar-brand" href="#home">
                        <img src="psl_logo.png"/>
                    </a></h2>
                    <div class="toggle"></div>
            </header>
            
        <table>
            <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Role</th>
            <th>Nationality</th>
            <th>Team ID</th>

            </tr>
            <?php
            $sql = "SELECT * FROM players";
            $result = $conn->query($sql);
            if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
            ?>
            <tr>

            <td> <?php  echo $row['player_id'];?></td>
            <td> <?php  echo $row['player_name'];?></td>
            <td> <?php  echo $row['player_contact'];?></td>
            <td> <?php  echo $row['player_role'];?></td>
            <td> <?php  echo $row['player_nationality'];?></td>
            <td> <?php  echo $row['team_id'];?></td>

            </tr>
            <?php
            }
            }
            else
            {
            ?>
            <tr>
            <th colspan="2">There's No data found!!!</th>
            </tr>
            <?php
            }
            ?>
        </table>
    </section>

    <div class="menu">
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="http://localhost/Project/Matches/printMatches/recordprint.php">Matches</a></li>
            <li><a href="http://localhost/Project/MatchUmpire/printMatchUmpire/recordprint.php">Match Umpire</a></li>
            <li><a href="http://localhost/Project/Players/printPlayer/recordprint.php">Players</a></li>
            <li><a href="http://localhost/project/PlayerStats/printPlayerStat/recordprint.php">Players Stats</a></li>
            <li><a href="http://localhost/project/Rules/printRules/recordprint.php">Rules</a></li>
            <li><a href="http://localhost/Project/Stadium/printStadium/recordPrint.php">Stadium</a></li>
            <li><a href="http://localhost/Project/Standings/printStanding/recordPrint.php">Standings</a></li>
            <li><a href="http://localhost/Project/TeamOwner/printTeamOwner/recordprint.php">Team Owners</a></li>
            <li><a href="http://localhost/Project/Teams/printTeams/recordprint.php">Teams</a></li>
            <li><a href="http://localhost/Project/Umpires/printUmpire/recordprint.php">Umpires</a></li>
        </ul>
    </div>

    <script>
        const menuToggle = document.querySelector('.toggle')
        const showcase = document.querySelector('.showcase')
        const opac = document.querySelector('.menu')

        menuToggle.addEventListener('click', () => {
            menuToggle.classList.toggle('active')
            showcase.classList.toggle('active')
            opac.classList.toggle('active')
        })
    </script>

</body>
</html>