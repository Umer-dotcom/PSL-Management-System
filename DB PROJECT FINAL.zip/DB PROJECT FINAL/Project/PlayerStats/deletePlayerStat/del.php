<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psl_management_system";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>
<link rel="shortest icon" type="text/css" href="image/bomb2.jpg">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

</head>
<body>

<h1 align="center">Delete Player Stat Record</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Player ID</th>
<th>Total Runs</th>
<th>Total Wickets</th>
<th>Strike Rate</th>
<th>6's</th>
<th>4's</th>
<th>50's</th>
<th>100's</th>

<?php
$sql = "SELECT * FROM player_stats";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['player_id'];?></td>
<td> <?php  echo $row['total_runs'];?></td>
<td> <?php  echo $row['total_wickets'];?></td>
<td> <?php  echo $row['strike_rate'];?></td>
<td> <?php  echo $row['6\'s'];?></td>
<td> <?php  echo $row['4\'s'];?></td>
<td> <?php  echo $row['50\'s'];?></td>
<td> <?php  echo $row['100\'s'];?></td>



 <td><a href="delete.php?edit_id=<?php echo $row['player_id']; ?>" alt="edit" >Delete Record</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>