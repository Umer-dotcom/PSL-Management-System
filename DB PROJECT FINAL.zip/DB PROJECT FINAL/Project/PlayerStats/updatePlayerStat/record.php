<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psl_management_system";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">Player Stats Record Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Player ID</th>
<th>Total Runs</th>
<th>Total Wickets</th>
<th>Strike Rate</th>
<th>6's</th>
<th>4's</th>
<th>50's</th>
<th>100's</th>

</tr>
<?php
$sql = "SELECT * FROM player_stats";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['player_id'];?></td>
<td> <?php  echo $row['total_runs'];?></td>
<td> <?php  echo $row['total_wickets'];?></td>
<td> <?php  echo $row['strike_rate'];?></td>
<td> <?php  echo $row['6\'s'];?></td>
<td> <?php  echo $row['4\'s'];?></td>
<td> <?php  echo $row['50\'s'];?></td>
<td> <?php  echo $row['100\'s'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['player_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>