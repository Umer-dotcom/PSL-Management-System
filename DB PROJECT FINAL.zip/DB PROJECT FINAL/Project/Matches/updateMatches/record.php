<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "psl_management_system";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">Mathces Record Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>Match ID</th>
<th>Date</th>
<th>Time</th>
<th>Stadium ID</th>
<th>Team1 ID</th>
<th>Team2 ID</th>

</tr>
<?php
$sql = "SELECT * FROM matches";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['match_id'];?></td>
<td> <?php  echo $row['date'];?></td>
<td> <?php  echo $row['time'];?></td>
<td> <?php  echo $row['stadium_id'];?></td>
<td> <?php  echo $row['team1_id'];?></td>
<td> <?php  echo $row['team2_id'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['match_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>